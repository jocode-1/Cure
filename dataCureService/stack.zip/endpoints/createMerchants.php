<?php
include_once('../inc/portal.php');
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");

$data = json_decode(@file_get_contents("php://input"), true);

$portal = new PortalUtility();

$merchant_name = trim(mysqli_real_escape_string($conn, !empty($data['merchant_name']) ? $data['merchant_name'] : ""));
$merchant_email = trim(mysqli_real_escape_string($conn, !empty($data['merchant_email']) ? $data['merchant_email'] : ""));
$merchant_phone = trim(mysqli_real_escape_string($conn, !empty($data['merchant_phone']) ? $data['merchant_phone'] : ""));
$merchant_address = trim(mysqli_real_escape_string($conn, !empty($data['merchant_address']) ? $data['merchant_address'] : ""));
$merchant_rate = trim(mysqli_real_escape_string($conn, !empty($data['merchant_rate']) ? $data['merchant_rate'] : ""));
$processing_rate = trim(mysqli_real_escape_string($conn, !empty($data['processing_rate']) ? $data['processing_rate'] : ""));
$insurrance = trim(mysqli_real_escape_string($conn, !empty($data['insurrance']) ? $data['insurrance'] : ""));
$commitment = trim(mysqli_real_escape_string($conn, !empty($data['commitment']) ? $data['commitment'] : ""));
$merchant_remita_key = trim(mysqli_real_escape_string($conn, !empty($data['merchant_remita_key']) ? $data['merchant_remita_key'] : ""));
$merchant_remita_id = trim(mysqli_real_escape_string($conn, !empty($data['merchant_remita_id']) ? $data['merchant_remita_id'] : ""));
$smtp_host = trim(mysqli_real_escape_string($conn, !empty($data['smtp_host']) ? $data['smtp_host'] : ""));
$smtp_email = trim(mysqli_real_escape_string($conn, !empty($data['smtp_email']) ? $data['smtp_email'] : ""));
$smtp_password = trim(mysqli_real_escape_string($conn, !empty($data['smtp_password']) ? $data['smtp_password'] : ""));

$user = $portal->create_merchant($conn,$merchant_name,$merchant_email,$merchant_phone,$merchant_address,$merchant_rate,$processing_rate,
$insurrance,$commitment,$merchant_remita_key,$merchant_remita_id,$smtp_host,$smtp_email,$smtp_password);

echo $user;
