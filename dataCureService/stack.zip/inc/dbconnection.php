<?php

 class database{


    private $host = "localhost";
    private $db_name = "merchant_reference";
    private $username = "root";
    private $password = "";
    public $conn;
   /* private $host = "localhost";
    private $db_name = "richwaymfb";
    private $username = "dtuzzy";
    private $password = "Javax.swing_2020";
    public $conn; */
 

    // get the database connection
    public function getConnection(){
  
        $this->conn = null;
  
        try{
            $this->conn = new mysqli($this->host,$this->username, $this->password, $this->db_name);
    
		//echo 'Success';
        }catch(Exception $exception){
            echo "Connection error: " . $exception->getMessage();
        }
  
        return $this->conn;
  
        return $this->conn;
    }
	
	
}

//$connect = new database();
//$connect->getConnection();


?>
